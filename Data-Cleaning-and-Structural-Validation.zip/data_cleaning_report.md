# Task 1: Data Cleaning & Structural Validation

## Problem Statement
The dataset contained duplicate entries, missing values, and inconsistent formatting.

## Steps Taken
1. Removed duplicate records.
2. Handled missing values.
3. Standardized email formatting.
4. Validated data structure and consistency.

## Outcome
The final dataset is accurate, consistent, and ready for analysis.
