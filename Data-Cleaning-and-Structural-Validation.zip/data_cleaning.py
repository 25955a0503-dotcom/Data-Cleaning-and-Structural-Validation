import pandas as pd

df = pd.read_csv('raw_data.csv')

df = df.drop_duplicates()
df['Email'] = df['Email'].fillna('Not Available')
df['Age'] = df['Age'].fillna('Not Available')
df['Email'] = df['Email'].astype(str).str.lower()

df.to_csv('cleaned_data.csv', index=False)

print('Data cleaning completed successfully!')
